moduleInfo = {
    "author": "r1a",
    "description": "Cross language importer for Framer",
    "hooker": True,
}

from .module import moduleMain

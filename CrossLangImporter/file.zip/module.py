import sys
import os
import subprocess
import ctypes
import importlib.abc
import importlib.util
import importlib.machinery
import time


class CustomLoader(importlib.abc.Loader):
    def __init__(self, so_path, fullname):
        super().__init__()

        self.so_path = so_path
        self.fullname = fullname

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        # load library
        lib = ctypes.cdll.LoadLibrary(self.so_path)

        # dynamic function getter
        def get_lib_attr(name):
            return getattr(lib, name)

        # bind to module
        module.__getattr__ = get_lib_attr


class CustomFinder(importlib.abc.MetaPathFinder):
    def __init__(self):
        super().__init__()

        self.supported_extensions: list[str] = []
        self.extension_handlers: dict[str, object] = {}
        self.os_ext = importlib.machinery.EXTENSION_SUFFIXES[-1][1:]

    def find_spec(self, fullname, path, target=None):
        # get import module name
        module_name = fullname.split(".")[-1]

        # module file search path
        search_paths = sys.path if path is None else path
        for base_path in search_paths:

            # possible file paths
            possible_paths = {
                "py": os.path.join(base_path, f"{module_name}.py"),
                "so": os.path.join(base_path, f"{module_name}.{self.os_ext}"),
            }
            for ext in self.supported_extensions:
                possible_paths[ext] = os.path.join(base_path, f"{module_name}.{ext}")

            # ignore python file
            if os.path.isfile(possible_paths["py"]):
                continue

            # process supported file types
            for ext, file_path in possible_paths.items():

                # ignore py and so
                if ext in ["py", "so"]:
                    continue

                # if find supported file type
                if os.path.isfile(file_path):

                    # ensure newest compiled
                    self._ensure_compiled(file_path, possible_paths["so"], ext)

                    # import use require
                    return self.require(possible_paths["so"], fullname)

        # not found
        return None

    def require(self, so_path, fullname):
        # custom module loader
        loader = CustomLoader(so_path, fullname)

        # create module spec
        return importlib.machinery.ModuleSpec(
            name=fullname, loader=loader, origin=so_path, is_package=True
        )

    def _ensure_compiled(self, file_path, so_path, ext):
        # get file changed time
        file_changed_time = os.path.getmtime(file_path)
        so_changed_time = os.path.getmtime(so_path) if os.path.exists(so_path) else -1

        # build if so file old
        if file_changed_time > so_changed_time:

            # compile file
            self._compile_file(self.extension_handlers[ext], file_path, so_path)

    def _compile_file(self, handler, file_path, so_path):
        # build command
        cmds = handler.build_command(file_path, so_path)

        # change working directory
        cwd = os.getcwd()
        os.chdir(os.path.dirname(file_path))

        # run command
        try:
            for cmd in cmds:
                result = subprocess.run(cmd, capture_output=True, text=True, check=True)
                handler.logger(f"Compiled {file_path} -> {so_path}")
                if result.stderr:
                    handler.logger("Compiler warnings: " + result.stderr)

        # catch errors
        except subprocess.CalledProcessError as e:
            raise ImportError(
                f"Compilation failed for {file_path}:\n"
                f"Exit code: {e.returncode}\n"
                f"Error: {e.stderr}"
            ) from e

        # if compiler not installed
        except FileNotFoundError:
            raise ImportError(handler.not_found_message)

        # change back working directory
        finally:
            os.chdir(cwd)

    def add_extension_handler(self, handler: object):
        self.supported_extensions.append(handler.extension)
        self.extension_handlers[handler.extension] = handler


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

        self.finder = CustomFinder()
        sys.meta_path.insert(0, self.finder)

    def __call__(self, handler: object):
        self.logger(f"Registered {handler.extension} handler")
        self.finder.add_extension_handler(handler)

    def Require(self, so_path):
        fullname = "m%d" % int(time.time())
        mSpec = self.finder.require(so_path, fullname)
        m = importlib.util.module_from_spec(mSpec)
        mSpec.loader.exec_module(m)
        return m

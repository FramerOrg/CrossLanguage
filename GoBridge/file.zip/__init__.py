moduleInfo = {
    "author": "r1a",
    "description": "Cross language importer - Golang Support",
    "hooker": False,
}

from .module import moduleMain

class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

        self.extension = "go"
        self.not_found_message = (
            "Go compiler not found. Install Go from https://golang.org/"
        )

    def build_command(self, file_path, so_path):
        return [
            ["go", "mod", "tidy"],
            ["go", "build", "-buildmode=c-shared", "-o", so_path, file_path],
        ]
